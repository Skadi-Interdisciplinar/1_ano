package com.example.skadi_beckend.model;

public class CD {
    //    Atributos
    private Integer id_cd;
    private String nome;
    private String cnpj;
    private String endereco;

    //     Construtor vazio
    public CD() {}

    //    Construtor
    public CD(Integer id_cd, String nome, String cnpj, String endereco) {
        this.id_cd = id_cd;
        this.nome = nome;
        this.cnpj = cnpj;
        this.endereco = endereco;
    }

    // Getters e Setters
    public Integer getId() { return id_cd; }
    public void setId(Integer id_cd) { this.id_cd = id_cd; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
}
