package com.example.skadi_beckend.dao;

import com.example.skadi_beckend.model.CD;
import Connection.ConnectionFactory;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CDDAO {

    public List<CD> listarTodos() throws SQLException {
        List<CD> lista = new ArrayList<>();
        String sql = "SELECT * FROM cd";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(new CD(
                        rs.getInt("id_cd"),
                        rs.getString("nome"),
                        rs.getString("cnpj"),
                        rs.getString("endereco")
                ));
            }
        }
        return lista;
    }

    public CD buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM cd WHERE id_cd = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new CD(rs.getInt("id_cd"), rs.getString("nome"), rs.getString("cnpj"), rs.getString("endereco"));
                }
            }
        }
        return null;
    }

    // Pesquisa com cnpj
    public CD buscarPorCnpj(String cnpj) throws SQLException {
        String sql = "SELECT * FROM cd WHERE cnpj = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cnpj);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new CD(rs.getInt("id_cd"), rs.getString("nome"), rs.getString("cnpj"), rs.getString("endereco"));
                }
            }
        }
        return null;
    }

    public void inserir(CD cd) throws SQLException {
        String sql = "INSERT INTO cd (nome, cnpj, endereco) VALUES (?, ?, ?)";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cd.getNome());
            stmt.setString(2, cd.getCnpj());
            stmt.setString(3, cd.getEndereco());
            stmt.executeUpdate();
        }
    }

    public void atualizar(CD cd) throws SQLException {
        String sql = "UPDATE cd SET nome = ?, cnpj = ?, endereco = ? WHERE id_cd = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cd.getNome());
            stmt.setString(2, cd.getCnpj());
            stmt.setString(3, cd.getEndereco());
            stmt.setInt(4, cd.getId());
            stmt.executeUpdate();
        }
    }

    public void deletar(int id) throws SQLException {
        String sql = "DELETE FROM cd WHERE id_cd = ?";
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}