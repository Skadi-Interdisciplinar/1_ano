package com.example.skadi_beckend.servlet;

import com.example.skadi_beckend.dao.CDDAO;
import com.example.skadi_beckend.model.CD;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/cd")
public class CDServlet extends HttpServlet {

    private CDDAO cdDAO;

    @Override
    public void init() throws ServletException {
        this.cdDAO = new CDDAO();
    }

    // Exibir telas do HTML
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Saber o que fazer
        String action = request.getParameter("action");
        if (action == null) {
            action = "listar"; // Ação padrão
        }

        try {
            if (action.equals("deletar")) {
                // Remove do banco e recarrega a página
                int id = Integer.parseInt(request.getParameter("id"));
                cdDAO.deletar(id);
                response.sendRedirect("cd?action=listar");

            } else if (action.equals("editar")) {
                // Pega os dados de um CD e manda para a tela preenchida
                int id = Integer.parseInt(request.getParameter("id"));
                CD cd = cdDAO.buscarPorId(id);
                request.setAttribute("cdParaEditar", cd);

                // Quando o html estiver pronto mudar o nome certinho
                request.getRequestDispatcher("cadastroCD.jsp").forward(request, response);

            } else if (action.equals("pesquisar")) {
            // Pega o CNPJ digitado na tela
            String cnpj = request.getParameter("cnpj_pesquisa");
            CD cd = cdDAO.buscarPorCnpj(cnpj);

            // Colocar em uma lista para a tabela do html(JSP) conseguir ler normalmente
            List<CD> lista = new java.util.ArrayList<>();
            if (cd != null) {
                lista.add(cd);
            }

            request.setAttribute("listaCDs", lista);
            request.getRequestDispatcher("listaCDs.jsp").forward(request, response);

        }
            else {
                // Pega todos os CDs e manda para a tela de listagem
                List<CD> lista = cdDAO.listarTodos();
                request.setAttribute("listaCDs", lista);

                // Quando o html estiver pronto mudar o nome certinho
                request.getRequestDispatcher("listaCDs.jsp").forward(request, response);
            }
        } catch (Exception e) {
            throw new ServletException("Erro no banco de dados: " + e.getMessage());
        }
    }

    // Receber
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Pega os dados digitados pelo usuário
        String idStr = request.getParameter("id");
        String nome = request.getParameter("nome");
        String cnpj = request.getParameter("cnpj");
        String endereco = request.getParameter("endereco");

        // Monta o objeto
        CD cd = new CD();
        cd.setNome(nome);
        cd.setCnpj(cnpj);
        cd.setEndereco(endereco);

        try {
            if (idStr == null || idStr.isEmpty()) {
                // Se não tem ID, Inserir
                cdDAO.inserir(cd);
            } else {
                // Se tem ID, Atualizar
                cd.setId(Integer.parseInt(idStr));
                cdDAO.atualizar(cd);
            }

            response.sendRedirect("cd?action=listar");

        } catch (Exception e) {
            throw new ServletException("Erro ao salvar CD: " + e.toString());
        }
    }
}